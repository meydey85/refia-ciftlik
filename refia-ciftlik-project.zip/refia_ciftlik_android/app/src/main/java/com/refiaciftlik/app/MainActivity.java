package com.refiaciftlik.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.webkit.*;
import android.widget.*;

public class MainActivity extends Activity {
    private WebView web;
    private FrameLayout root;
    private static final int CAMERA_REQ = 1001;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(11,77,43));
        getWindow().setNavigationBarColor(Color.rgb(11,77,43));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(11,77,43));

        LinearLayout splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        ImageView logo = new ImageView(this);
        logo.setImageResource(com.refiaciftlik.app.R.drawable.refia_icon);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        splash.addView(logo, new LinearLayout.LayoutParams(230,230));
        TextView title = new TextView(this);
        title.setText("REFİA ÇİFTLİK");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        splash.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView sub = new TextView(this);
        sub.setText("Büyükbaş • Kanatlı • Çiftlik Yönetimi");
        sub.setTextColor(Color.rgb(242,193,78));
        sub.setTextSize(14);
        sub.setGravity(Gravity.CENTER);
        splash.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        root.addView(splash, new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);

        new Handler().postDelayed(() -> openApp(), 700);
        if (android.os.Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQ);
    }

    private void openApp() {
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (request.getResources() != null) request.grant(request.getResources());
                });
            }
        });
        web.loadUrl("file:///android_asset/index.html");
        root.removeAllViews();
        root.addView(web, new FrameLayout.LayoutParams(-1,-1));
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
