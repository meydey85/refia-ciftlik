/* Firebase Cloud Messaging service worker.
   Add Firebase Messaging compat SDK + your Firebase config here before production.
*/
self.addEventListener("install",()=>self.skipWaiting());
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("notificationclick",e=>{e.notification.close();e.waitUntil(clients.openWindow("./"));});
