# Refia Çiftlik - no custom rules yet
