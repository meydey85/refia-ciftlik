REFIA ÇİFTLİK — ANDROID PROJESİ
================================

Bu proje Android Studio/Gradle ile APK üretmek için hazırlanmıştır.

Uygulama:
- Ad: Refia Çiftlik
- Paket: com.refiaciftlik.app
- Büyükbaş + kanatlı modülü
- Yumurta, kuluçka, sağlık, satış, yem, yedekleme
- Kamera izni ve WebView kamera erişimi altyapısı
- Refia Çiftlik uygulama ikonu

APK oluşturma:
1. Android Studio'yu kurun.
2. Bu klasörü Android Studio ile açın.
3. Gradle sync tamamlandıktan sonra Build > Build APK(s) seçin.
4. Test APK'sı app/build/outputs/apk/debug/ altında oluşur.

Not: Bu çalışma ortamında Android SDK/Gradle dağıtımı bulunmadığından burada APK derlemesi yapılamadı.
